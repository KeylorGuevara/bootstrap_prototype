from django.db import models

class Canton(models.Model):
    nombreCanton=models.CharField(max_length=100)
    codigoCanton=models.CharField(max_length=10)
    provinciaCanton=models.CharField(max_length=20)


class Distrito(models.Model):
    nombreDistrito=models.CharField(max_length=100)
    codigoDistrito=models.CharField(max_length=10)
    cantonPerteneciente=models.ForeignKey(Canton,blank=True)